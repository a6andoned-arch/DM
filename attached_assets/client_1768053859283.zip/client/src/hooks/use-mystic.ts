import { useMutation } from "@tanstack/react-query";
import { api, type TarotDrawResponse, type FortuneResponse } from "@shared/routes";
import { apiRequest } from "@/lib/queryClient";

// ============================================
// MYSTIC HOOKS
// ============================================

export function useTarotDraw() {
  return useMutation({
    mutationFn: async ({ question, count = 3 }: { question?: string; count?: number }) => {
      const res = await apiRequest("POST", api.tarot.draw.path, { question, count });
      const data = await res.json();
      return api.tarot.draw.responses[200].parse(data) as TarotDrawResponse;
    },
  });
}

export function useFortune() {
  return useMutation({
    mutationFn: async (input: { name?: string; dob: string; birthPlace: string; type: 'kundali' | 'numerology' }) => {
      // Validate input using the shared schema if possible, or simple check
      const res = await apiRequest("POST", api.fortune.generate.path, input);
      const data = await res.json();
      return api.fortune.generate.responses[200].parse(data) as FortuneResponse;
    },
  });
}

import { Layout } from "@/components/Layout";

export default function Disclaimer() {
  return (
    <Layout>
      <div className="max-w-2xl mx-auto py-12 px-4">
        <h1 className="font-creepster text-4xl text-primary text-center mb-8">Disclaimer</h1>
        
        <div className="space-y-6 font-cinzel text-gray-300 text-justify leading-relaxed bg-black/40 p-8 rounded-xl border border-white/10">
          <p>
            This website (VooDoo) is intended solely for entertainment purposes. The readings, games, and fortune-telling features are simulated and should not be taken as factual prediction of future events.
          </p>
          
          <p>
            While we incorporate concepts from real-world Tarot, Numerology, and Kundali traditions, the automated nature of this platform means results are generalized. Destiny is not written in stone; it is forged by your own hands and decisions.
          </p>
          
          <p>
            The Ouija and VooDoo features are digital games designed for amusement. We do not endorse or promote the practice of dark arts or harmful intent towards others.
          </p>
          
          <p className="text-center text-primary font-bold mt-8">
            Play responsibly. Unleash the magic within you.
          </p>
        </div>
      </div>
    </Layout>
  );
}

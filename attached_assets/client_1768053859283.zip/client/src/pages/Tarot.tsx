import { Layout } from "@/components/Layout";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { MysticButton } from "@/components/MysticButton";
import { useTarotDraw } from "@/hooks/use-mystic";
import { Loader2, RefreshCw, Sparkles } from "lucide-react";

export default function Tarot() {
  const [gameState, setGameState] = useState<'intro' | 'picking' | 'revealed'>('intro');
  const [selectedCards, setSelectedCards] = useState<number[]>([]);
  const { mutate, data: reading, isPending } = useTarotDraw();

  const handleStart = () => {
    setGameState('picking');
    setSelectedCards([]);
  };

  const handleCardClick = (index: number) => {
    if (selectedCards.includes(index)) return;
    
    const newSelection = [...selectedCards, index];
    setSelectedCards(newSelection);

    if (newSelection.length === 3) {
      mutate(
        { count: 3 },
        {
          onSuccess: () => setGameState('revealed')
        }
      );
    }
  };

  const handleReset = () => {
    setGameState('intro');
    setSelectedCards([]);
  };

  return (
    <Layout>
      <div className="flex flex-col items-center justify-center min-h-[70vh] gap-8">
        
        <div className="text-center space-y-4">
          <h1 className="font-creepster text-5xl text-primary text-glow">Tarot Reading</h1>
          <p className="font-cinzel text-muted-foreground max-w-lg mx-auto">
            {gameState === 'intro' && "The cards are waiting. Will you dare to see what fate holds?"}
            {gameState === 'picking' && `Select 3 cards to reveal your destiny (${selectedCards.length}/3)`}
            {gameState === 'revealed' && "Your fate has been sealed."}
          </p>
        </div>

        {/* GAME AREA */}
        <div className="w-full max-w-5xl min-h-[400px] flex items-center justify-center perspective-1000 relative">
          
          <AnimatePresence mode="wait">
            
            {/* INTRO STATE */}
            {gameState === 'intro' && (
              <motion.div 
                initial={{ opacity: 0 }} 
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex flex-col gap-6"
              >
                <div className="relative group cursor-pointer" onClick={handleStart}>
                  <div className="w-48 h-72 bg-card rounded-xl border-2 border-white/10 shadow-2xl relative overflow-hidden group-hover:shadow-[0_0_30px_rgba(139,0,0,0.5)] transition-all duration-500">
                    <div className="absolute inset-0 bg-[repeating-linear-gradient(45deg,transparent,transparent_10px,#222_10px,#222_20px)] opacity-50" />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className="font-creepster text-6xl text-white/20 group-hover:text-primary transition-colors">?</span>
                    </div>
                  </div>
                </div>
                <MysticButton onClick={handleStart} className="w-full">
                  Shuffle Deck
                </MysticButton>
              </motion.div>
            )}

            {/* PICKING STATE */}
            {gameState === 'picking' && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex flex-wrap justify-center gap-4"
              >
                {[...Array(5)].map((_, i) => (
                  <motion.div
                    key={i}
                    initial={{ x: -100, opacity: 0, rotate: -10 }}
                    animate={{ x: 0, opacity: 1, rotate: (i - 2) * 5 }}
                    transition={{ delay: i * 0.1, type: "spring" }}
                    whileHover={{ y: -20, scale: 1.05, zIndex: 10 }}
                    onClick={() => handleCardClick(i)}
                    className={`
                      w-32 h-48 md:w-40 md:h-60 rounded-xl cursor-pointer transition-all duration-300 border-2
                      ${selectedCards.includes(i) 
                        ? 'border-secondary shadow-[0_0_20px_#39ff14] translate-y-[-20px]' 
                        : 'border-white/10 bg-card hover:border-primary'}
                    `}
                  >
                    <div className="w-full h-full bg-[repeating-linear-gradient(45deg,#1a1a1a,#1a1a1a_10px,#0a0a0a_10px,#0a0a0a_20px)] rounded-lg relative overflow-hidden">
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="w-20 h-20 border-2 border-white/5 rounded-full flex items-center justify-center">
                          <div className="w-16 h-16 border border-white/5 rotate-45" />
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </motion.div>
            )}

            {/* LOADING STATE (Overlay) */}
            {isPending && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="absolute inset-0 flex flex-col items-center justify-center bg-black/80 backdrop-blur-sm z-50 rounded-xl"
              >
                <Loader2 className="w-16 h-16 text-secondary animate-spin mb-4" />
                <p className="font-creepster text-xl text-white animate-pulse">Consulting the spirits...</p>
              </motion.div>
            )}

            {/* REVEALED STATE */}
            {gameState === 'revealed' && reading && (
              <motion.div 
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                className="w-full max-w-4xl"
              >
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
                  {reading.cards.map((card, idx) => (
                    <motion.div
                      key={idx}
                      initial={{ rotateY: 90 }}
                      animate={{ rotateY: 0 }}
                      transition={{ delay: idx * 0.3, duration: 0.8 }}
                      className="bg-card border border-white/10 p-4 rounded-xl shadow-lg relative overflow-hidden group hover:border-primary/50 transition-colors"
                    >
                      <div className="aspect-[2/3] bg-black/50 rounded-lg mb-4 overflow-hidden relative">
                         {card.image ? (
                           <img src={card.image} alt={card.name} className="w-full h-full object-cover opacity-80 group-hover:scale-110 transition-transform duration-700" />
                         ) : (
                           <div className="w-full h-full flex items-center justify-center bg-zinc-900">
                             <span className="font-creepster text-4xl text-white/20">{idx + 1}</span>
                           </div>
                         )}
                         <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-80" />
                      </div>
                      <h3 className="font-cinzel font-bold text-lg text-secondary mb-1">{card.name}</h3>
                      <p className="text-xs text-gray-400 italic mb-2">{card.meaning}</p>
                      <p className="text-sm text-gray-300 leading-relaxed">{card.description}</p>
                    </motion.div>
                  ))}
                </div>

                <div className="bg-white/5 border border-white/10 rounded-2xl p-8 mb-8 backdrop-blur-md">
                  <div className="flex items-center gap-3 mb-4">
                    <Sparkles className="text-primary w-6 h-6" />
                    <h3 className="font-creepster text-2xl text-white">The Spirits Say...</h3>
                  </div>
                  <p className="font-cinzel text-lg text-gray-300 leading-relaxed">
                    {reading.reading}
                  </p>
                </div>

                <div className="flex justify-center">
                  <MysticButton onClick={handleReset} variant="outline">
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Read Again
                  </MysticButton>
                </div>
              </motion.div>
            )}
            
          </AnimatePresence>
        </div>

      </div>
    </Layout>
  );
}

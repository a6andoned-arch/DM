import { Layout } from "@/components/Layout";
import { Link } from "wouter";
import { motion } from "framer-motion";

const features = [
  {
    title: "Tarot",
    desc: "Unveil your destiny",
    href: "/tarot",
    color: "from-purple-900 to-black",
    border: "border-purple-500/30",
    shadow: "hover:shadow-purple-500/20",
    icon: "🎴"
  },
  {
    title: "Ouija",
    desc: "Speak to the beyond",
    href: "/ouija",
    color: "from-red-900 to-black",
    border: "border-red-500/30",
    shadow: "hover:shadow-red-500/20",
    icon: "🔮"
  },
  {
    title: "Fortune Ball",
    desc: "Kundali & Numerology",
    href: "/fortune",
    color: "from-blue-900 to-black",
    border: "border-blue-500/30",
    shadow: "hover:shadow-blue-500/20",
    icon: "⚡"
  },
  {
    title: "VooDoo",
    desc: "Stick a pin in it",
    href: "/voodoo",
    color: "from-green-900 to-black",
    border: "border-green-500/30",
    shadow: "hover:shadow-green-500/20",
    icon: "🧸"
  }
];

export default function Home() {
  return (
    <Layout>
      <div className="flex flex-col items-center justify-center min-h-[80vh] gap-12 text-center">
        
        <div className="space-y-4 max-w-3xl">
          <motion.h1 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1 }}
            className="font-creepster text-6xl md:text-8xl text-primary drop-shadow-[0_0_15px_rgba(139,0,0,0.8)]"
          >
            VooDoo
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5, duration: 1 }}
            className="font-cinzel text-xl md:text-2xl text-muted-foreground tracking-widest"
          >
            Lets Unleash The Magic
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full max-w-4xl">
          {features.map((feature, i) => (
            <Link key={feature.title} href={feature.href} className="block group">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 * i }}
                whileHover={{ scale: 1.02, translateY: -5 }}
                className={`
                  relative h-48 rounded-2xl p-8 flex flex-col items-center justify-center gap-4
                  bg-gradient-to-br ${feature.color} border ${feature.border}
                  shadow-2xl ${feature.shadow} transition-all duration-300
                  overflow-hidden cursor-pointer
                `}
              >
                <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/dark-matter.png')] opacity-30" />
                
                <span className="text-4xl filter drop-shadow-lg z-10 group-hover:scale-125 transition-transform duration-300">
                  {feature.icon}
                </span>
                
                <div className="z-10 text-center">
                  <h2 className="font-creepster text-3xl text-white tracking-wider mb-2 group-hover:text-secondary transition-colors">
                    {feature.title}
                  </h2>
                  <p className="font-cinzel text-sm text-gray-400 group-hover:text-white transition-colors">
                    {feature.desc}
                  </p>
                </div>

                {/* Hover Glow Effect */}
                <div className="absolute inset-0 bg-white/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              </motion.div>
            </Link>
          ))}
        </div>
      </div>
    </Layout>
  );
}

import { Layout } from "@/components/Layout";
import { useState, useRef, useEffect } from "react";
import { MysticButton } from "@/components/MysticButton";
import { Upload, Download, RotateCcw } from "lucide-react";
import html2canvas from "html2canvas";
import { motion } from "framer-motion";

export default function VooDoo() {
  const [image, setImage] = useState<string | null>(null);
  const [pins, setPins] = useState<Array<{x: number, y: number, color: string}>>([]);
  const canvasRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const pinColors = ["#ff0000", "#00ff00", "#0000ff", "#ffff00", "#ffffff"];
  const [selectedColor, setSelectedColor] = useState(pinColors[0]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
        setPins([]); // Clear pins on new image
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCanvasClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!image) return;
    
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;

    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    setPins([...pins, { x, y, color: selectedColor }]);
  };

  const handleSave = async () => {
    if (!canvasRef.current) return;
    
    try {
      const canvas = await html2canvas(canvasRef.current);
      const link = document.createElement("a");
      link.download = "voodoo-doll.png";
      link.href = canvas.toDataURL();
      link.click();
    } catch (err) {
      console.error("Failed to capture screenshot", err);
    }
  };

  return (
    <Layout>
      <div className="flex flex-col items-center gap-8 py-8">
        
        <div className="text-center space-y-2">
          <h1 className="font-creepster text-5xl text-primary text-glow">VooDoo Doll</h1>
          <p className="font-cinzel text-muted-foreground">Upload a photo. Place your pins. Unleash chaos.</p>
        </div>

        <div className="w-full max-w-4xl flex flex-col md:flex-row gap-8 items-start justify-center">
          
          {/* Controls */}
          <div className="w-full md:w-64 space-y-6 bg-card border border-white/10 p-6 rounded-xl h-fit">
            <div className="space-y-2">
              <label className="font-cinzel text-sm text-gray-400">1. Upload Target</label>
              <input 
                type="file" 
                ref={fileInputRef}
                onChange={handleImageUpload}
                accept="image/*"
                className="hidden"
              />
              <MysticButton 
                variant="outline" 
                className="w-full text-sm py-2"
                onClick={() => fileInputRef.current?.click()}
              >
                <Upload className="w-4 h-4 mr-2" /> Select Photo
              </MysticButton>
            </div>

            <div className="space-y-2">
              <label className="font-cinzel text-sm text-gray-400">2. Select Pin</label>
              <div className="flex gap-2 justify-center flex-wrap">
                {pinColors.map(color => (
                  <button
                    key={color}
                    onClick={() => setSelectedColor(color)}
                    className={`w-8 h-8 rounded-full border-2 transition-transform hover:scale-110 ${selectedColor === color ? 'border-white scale-110' : 'border-transparent'}`}
                    style={{ backgroundColor: color }}
                  />
                ))}
              </div>
            </div>

            <div className="pt-4 border-t border-white/10 space-y-3">
              <MysticButton onClick={handleSave} className="w-full text-sm py-2" disabled={!image}>
                <Download className="w-4 h-4 mr-2" /> Save Image
              </MysticButton>
              
              <button 
                onClick={() => setPins([])}
                className="w-full text-center text-xs text-muted-foreground hover:text-white flex items-center justify-center gap-1"
              >
                <RotateCcw className="w-3 h-3" /> Clear Pins
              </button>
            </div>
          </div>

          {/* Canvas Area */}
          <div className="flex-1 flex justify-center">
            <div 
              className="relative w-[300px] h-[400px] md:w-[400px] md:h-[533px] bg-black/30 border-2 border-dashed border-white/20 rounded-xl overflow-hidden flex items-center justify-center cursor-crosshair shadow-2xl"
              onClick={handleCanvasClick}
              ref={canvasRef}
            >
              {image ? (
                <>
                  <img src={image} alt="Voodoo Target" className="w-full h-full object-cover" />
                  {/* Overlay texture for doll effect */}
                  <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/burlap.png')] opacity-30 pointer-events-none mix-blend-multiply" />
                  
                  {pins.map((pin, i) => (
                    <motion.div
                      key={i}
                      initial={{ scale: 2, opacity: 0, y: -50 }}
                      animate={{ scale: 1, opacity: 1, y: 0 }}
                      className="absolute w-4 h-4 rounded-full shadow-lg"
                      style={{ 
                        left: pin.x - 8, 
                        top: pin.y - 8, 
                        backgroundColor: pin.color,
                        boxShadow: `0 0 10px ${pin.color}`
                      }}
                    >
                      {/* Pin needle visual */}
                      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-1 h-3 bg-white/50 -rotate-45 transform origin-bottom-right" />
                    </motion.div>
                  ))}
                </>
              ) : (
                <div className="text-center p-8 opacity-50">
                   <div className="w-32 h-32 mx-auto mb-4 border-4 border-dashed border-white/20 rounded-full flex items-center justify-center">
                     <span className="text-6xl">?</span>
                   </div>
                   <p className="font-cinzel">Upload a photo to begin the ritual</p>
                </div>
              )}
            </div>
          </div>

        </div>
      </div>
    </Layout>
  );
}

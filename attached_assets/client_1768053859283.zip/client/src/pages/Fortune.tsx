import { Layout } from "@/components/Layout";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useFortune } from "@/hooks/use-mystic";
import { MysticButton } from "@/components/MysticButton";
import { motion, AnimatePresence } from "framer-motion";
import { Sparkles, MapPin, Calendar, User } from "lucide-react";
import clsx from "clsx";

const fortuneSchema = z.object({
  name: z.string().optional(),
  dob: z.string().min(1, "Date of birth is required"),
  birthPlace: z.string().min(1, "Birth place is required"),
  type: z.enum(["kundali", "numerology"]),
});

type FortuneForm = z.infer<typeof fortuneSchema>;

export default function Fortune() {
  const { register, handleSubmit, watch, formState: { errors } } = useForm<FortuneForm>({
    resolver: zodResolver(fortuneSchema),
    defaultValues: { type: "kundali" }
  });

  const { mutate, data, isPending, reset } = useFortune();
  const selectedType = watch("type");

  const onSubmit = (data: FortuneForm) => {
    mutate(data);
  };

  return (
    <Layout>
      <div className="flex flex-col items-center min-h-[80vh] gap-8 relative z-10">
        
        {/* Animated Crystal Ball Header */}
        <div className="relative w-48 h-48 md:w-64 md:h-64 my-8">
          <div className="absolute inset-0 rounded-full bg-gradient-to-br from-indigo-500/20 to-purple-900/40 blur-xl animate-pulse" />
          <motion.div 
            animate={{ rotate: 360 }}
            transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            className="w-full h-full rounded-full border border-white/10 shadow-[inset_0_0_50px_rgba(255,255,255,0.1)] backdrop-blur-sm overflow-hidden relative"
          >
             <div className="absolute inset-0 bg-[url('https://media.giphy.com/media/3o7bu3XilJ5BOiSGic/giphy.gif')] opacity-20 mix-blend-screen bg-cover bg-center" />
             <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-black/50" />
          </motion.div>
          {/* Base */}
          <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 w-32 h-8 bg-[#1a1a1a] rounded-[50%] blur-sm shadow-2xl" />
        </div>

        <h1 className="font-creepster text-5xl text-center text-primary text-glow">
          Fortune Ball
        </h1>

        <AnimatePresence mode="wait">
          {!data ? (
            <motion.form 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              onSubmit={handleSubmit(onSubmit)} 
              className="w-full max-w-md bg-card/50 backdrop-blur-md border border-white/10 p-8 rounded-2xl shadow-2xl space-y-6"
            >
              <div className="grid grid-cols-2 gap-4 mb-6">
                <button
                  type="button"
                  onClick={() => register("type").onChange({ target: { value: "kundali", name: "type" } })}
                  className={clsx(
                    "py-3 rounded-lg font-cinzel transition-all border",
                    selectedType === "kundali" 
                      ? "bg-secondary text-black border-secondary shadow-[0_0_15px_rgba(57,255,20,0.4)]" 
                      : "bg-black/40 text-gray-400 border-white/10 hover:border-white/30"
                  )}
                >
                  Kundali
                </button>
                <button
                  type="button"
                  onClick={() => register("type").onChange({ target: { value: "numerology", name: "type" } })}
                  className={clsx(
                    "py-3 rounded-lg font-cinzel transition-all border",
                    selectedType === "numerology" 
                      ? "bg-secondary text-black border-secondary shadow-[0_0_15px_rgba(57,255,20,0.4)]" 
                      : "bg-black/40 text-gray-400 border-white/10 hover:border-white/30"
                  )}
                >
                  Numerology
                </button>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-cinzel text-gray-400 flex items-center gap-2">
                    <User className="w-4 h-4" /> Name (Optional)
                  </label>
                  <input 
                    {...register("name")}
                    className="w-full bg-black/50 border border-white/10 rounded-lg p-3 text-white focus:border-secondary outline-none transition-colors"
                    placeholder="Enter your name"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-cinzel text-gray-400 flex items-center gap-2">
                    <Calendar className="w-4 h-4" /> Date of Birth
                  </label>
                  <input 
                    type="date"
                    {...register("dob")}
                    className="w-full bg-black/50 border border-white/10 rounded-lg p-3 text-white focus:border-secondary outline-none transition-colors [color-scheme:dark]"
                  />
                  {errors.dob && <p className="text-red-500 text-xs">{errors.dob.message}</p>}
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-cinzel text-gray-400 flex items-center gap-2">
                    <MapPin className="w-4 h-4" /> Place of Birth
                  </label>
                  <input 
                    {...register("birthPlace")}
                    className="w-full bg-black/50 border border-white/10 rounded-lg p-3 text-white focus:border-secondary outline-none transition-colors"
                    placeholder="City, Country"
                  />
                  {errors.birthPlace && <p className="text-red-500 text-xs">{errors.birthPlace.message}</p>}
                </div>
              </div>

              <MysticButton type="submit" isLoading={isPending} className="w-full mt-4">
                Reveal My Fate
              </MysticButton>
            </motion.form>
          ) : (
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="w-full max-w-2xl bg-black/60 border border-secondary/30 p-8 rounded-2xl backdrop-blur-md relative overflow-hidden"
            >
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-secondary to-transparent" />
              
              <div className="text-center mb-8">
                <Sparkles className="w-12 h-12 text-secondary mx-auto mb-4 animate-spin-slow" />
                <h2 className="font-cinzel text-3xl text-white mb-2">The Stars Have Spoken</h2>
                <div className="w-24 h-px bg-white/20 mx-auto" />
              </div>

              <div className="prose prose-invert max-w-none font-cinzel text-gray-300 leading-relaxed text-justify">
                {data.prediction}
              </div>

              <div className="mt-8 flex justify-center">
                <MysticButton onClick={() => reset()} variant="outline">
                  Consult Again
                </MysticButton>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

      </div>
    </Layout>
  );
}

import { Link } from "wouter";
import { Layout } from "@/components/Layout";
import { AlertTriangle } from "lucide-react";

export default function NotFound() {
  return (
    <Layout>
      <div className="min-h-[60vh] flex flex-col items-center justify-center text-center gap-6">
        <AlertTriangle className="w-24 h-24 text-destructive animate-pulse" />
        <h1 className="font-creepster text-6xl text-white">404</h1>
        <p className="font-cinzel text-xl text-muted-foreground">
          You have wandered into the void. This page does not exist in this realm.
        </p>
        <Link href="/" className="font-cinzel text-primary hover:text-red-400 underline underline-offset-4">
          Return to Safety
        </Link>
      </div>
    </Layout>
  );
}

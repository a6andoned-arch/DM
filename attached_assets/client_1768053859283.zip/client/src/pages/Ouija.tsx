import { Layout } from "@/components/Layout";
import { useState, useRef, useEffect } from "react";
import { motion, useAnimation } from "framer-motion";
import { MysticButton } from "@/components/MysticButton";

export default function Ouija() {
  const [question, setQuestion] = useState("");
  const [isPlaying, setIsPlaying] = useState(false);
  const planchetteControls = useAnimation();
  const boardRef = useRef<HTMLDivElement>(null);

  const letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("");
  const numbers = "1234567890".split("");

  // Simulated answers for the game
  const answers = ["YES", "NO", "MAYBE", "LATER", "SOON", "NEVER", "ALWAYS", "RUN"];

  const handleAsk = async () => {
    if (!question.trim()) return;
    setIsPlaying(true);
    
    // Animate planchette randomly for effect
    await planchetteControls.start({
      x: [0, 50, -50, 20, -20, 0],
      y: [0, 30, -30, 20, -20, 0],
      transition: { duration: 2, ease: "easeInOut" }
    });

    // Pick random answer
    const answer = answers[Math.floor(Math.random() * answers.length)];
    
    // Simulate spelling out answer (simple version just goes to center text area effectively)
    // In a full version, we'd calculate coordinates of each letter.
    // Here we'll just show the answer in a spooky way after the movement.
    
    setTimeout(() => {
      setIsPlaying(false);
      setQuestion(""); // Clear input
      // Show result dialog or overlay could go here, but we'll use state in the UI
    }, 2500);
  };

  return (
    <Layout>
      <div className="flex flex-col items-center gap-8 py-10">
        
        <div className="text-center">
          <h1 className="font-creepster text-5xl text-primary text-glow mb-2">Ouija Board</h1>
          <p className="font-cinzel text-muted-foreground">Ask the spirits a question, if you dare.</p>
        </div>

        {/* BOARD */}
        <div className="relative w-full max-w-3xl aspect-[1.5] bg-[#1a1410] rounded-lg shadow-[0_0_50px_rgba(0,0,0,0.8)] border-[12px] border-[#3e2723] overflow-hidden select-none" ref={boardRef}>
          {/* Texture */}
          <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/wood-pattern.png')] opacity-50 pointer-events-none" />
          
          {/* Decor */}
          <div className="absolute top-4 left-4 right-4 flex justify-between font-creepster text-3xl text-[#8d6e63] opacity-60">
            <span>SUN</span>
            <span>MOON</span>
          </div>

          {/* YES / NO */}
          <div className="absolute top-16 w-full flex justify-center gap-32 font-cinzel text-4xl font-bold text-[#d7ccc8]">
            <span>YES</span>
            <span>NO</span>
          </div>

          {/* Letters Arc */}
          <div className="absolute top-1/3 left-0 right-0 flex flex-wrap justify-center px-12 gap-x-6 gap-y-2">
            {letters.map((l) => (
              <span key={l} className="font-cinzel text-2xl md:text-4xl text-[#d7ccc8] w-8 text-center">{l}</span>
            ))}
          </div>

          {/* Numbers */}
          <div className="absolute bottom-32 left-0 right-0 flex justify-center gap-6 font-cinzel text-2xl text-[#d7ccc8]">
            {numbers.map((n) => (
              <span key={n}>{n}</span>
            ))}
          </div>

          {/* Goodbye */}
          <div className="absolute bottom-8 left-0 right-0 text-center font-cinzel text-4xl font-bold text-[#d7ccc8]">
            GOOD BYE
          </div>

          {/* Planchette */}
          <motion.div
            animate={planchetteControls}
            drag
            dragConstraints={boardRef}
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-32 h-40 z-50 cursor-move"
            style={{ x: "-50%", y: "-50%" }}
          >
            {/* Planchette Shape (SVG) */}
            <svg viewBox="0 0 100 130" className="drop-shadow-2xl">
              <path d="M50 0 C 20 20, 0 50, 10 80 C 15 110, 30 130, 50 130 C 70 130, 85 110, 90 80 C 100 50, 80 20, 50 0 Z" fill="#f5f5f5" />
              <circle cx="50" cy="55" r="15" fill="none" stroke="#333" strokeWidth="2" />
              {/* Viewing Glass */}
              <circle cx="50" cy="55" r="12" fill="rgba(255,255,255,0.3)" /> 
            </svg>
          </motion.div>
        </div>

        {/* CONTROLS */}
        <div className="w-full max-w-lg space-y-4">
          <input 
            type="text" 
            placeholder="Type your question here..."
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            disabled={isPlaying}
            className="w-full bg-black/50 border border-white/20 rounded-lg p-4 text-center font-cinzel text-white focus:border-primary outline-none focus:ring-1 focus:ring-primary transition-all"
          />
          <MysticButton 
            onClick={handleAsk} 
            disabled={!question || isPlaying} 
            className="w-full"
            variant="primary"
          >
            {isPlaying ? "Summoning..." : "Ask The Spirits"}
          </MysticButton>
        </div>

      </div>
    </Layout>
  );
}

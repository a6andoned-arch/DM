import { motion } from "framer-motion";
import { Loader2 } from "lucide-react";
import { clsx } from "clsx";

interface MysticButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "outline";
  isLoading?: boolean;
}

export function MysticButton({ 
  children, 
  variant = "primary", 
  isLoading, 
  className,
  ...props 
}: MysticButtonProps) {
  const baseStyles = "relative px-8 py-4 rounded-lg font-creepster text-xl tracking-widest uppercase overflow-hidden group transition-all duration-300";
  
  const variants = {
    primary: "bg-primary text-white hover:bg-red-800 shadow-[0_0_20px_rgba(139,0,0,0.4)] hover:shadow-[0_0_30px_rgba(139,0,0,0.6)] border border-red-900",
    secondary: "bg-secondary text-black hover:bg-green-400 shadow-[0_0_20px_rgba(57,255,20,0.4)] hover:shadow-[0_0_30px_rgba(57,255,20,0.6)] font-bold",
    outline: "bg-transparent border-2 border-primary text-primary hover:bg-primary/10 hover:shadow-[0_0_15px_rgba(139,0,0,0.3)]",
  };

  return (
    <motion.button
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      disabled={isLoading || props.disabled}
      className={clsx(baseStyles, variants[variant], className)}
      {...props}
    >
      <span className="relative z-10 flex items-center justify-center gap-2">
        {isLoading && <Loader2 className="w-5 h-5 animate-spin" />}
        {children}
      </span>
      
      {/* Glitch effect overlay on hover */}
      <div className="absolute inset-0 bg-white/10 translate-y-full group-hover:translate-y-0 transition-transform duration-300 skew-y-12" />
    </motion.button>
  );
}

import { Heart } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-black/90 border-t border-white/5 py-8 mt-auto relative z-10">
      <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-6">
        <p className="font-cinzel text-sm text-muted-foreground">
          © Voo-Doo - Lets Unleash The Magic
        </p>
        
        <div className="flex items-center gap-6">
          <a href="/disclaimer" className="text-xs text-muted-foreground hover:text-white transition-colors">
            Disclaimer
          </a>
          
          <a 
            href="https://tango.me/voido" 
            target="_blank" 
            rel="noopener noreferrer"
            className="
              px-6 py-2 rounded-full bg-gradient-to-r from-primary to-red-900 
              text-white font-bold font-cinzel text-sm tracking-wider
              shadow-[0_0_15px_rgba(139,0,0,0.5)] hover:shadow-[0_0_25px_rgba(139,0,0,0.8)]
              transform hover:-translate-y-1 transition-all duration-300 flex items-center gap-2
            "
          >
            <Heart className="w-4 h-4 fill-white" />
            Donate
          </a>
        </div>
      </div>
    </footer>
  );
}

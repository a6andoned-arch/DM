import { Header } from "./Header";
import { Footer } from "./Footer";
import { motion } from "framer-motion";

export function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen flex flex-col bg-background relative overflow-hidden">
      {/* Fog Animation */}
      <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden opacity-30">
        <div className="absolute top-0 left-0 w-[200%] h-full bg-[url('https://raw.githubusercontent.com/danielstuart14/CSS_FOG_ANIMATION/master/img/fog1.png')] animate-[fog_20s_linear_infinite] bg-repeat-x opacity-50"></div>
        <div className="absolute top-0 left-0 w-[200%] h-full bg-[url('https://raw.githubusercontent.com/danielstuart14/CSS_FOG_ANIMATION/master/img/fog2.png')] animate-[fog_10s_linear_infinite_reverse] bg-repeat-x opacity-30"></div>
      </div>

      <Header />
      
      <main className="flex-1 relative z-10 pt-24 px-4 pb-12 w-full max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.5 }}
        >
          {children}
        </motion.div>
      </main>

      <Footer />

      <style jsx global>{`
        @keyframes fog {
          0% { transform: translate3d(0, 0, 0); }
          100% { transform: translate3d(-50%, 0, 0); }
        }
      `}</style>
    </div>
  );
}

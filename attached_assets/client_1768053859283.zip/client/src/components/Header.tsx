import { Link, useLocation } from "wouter";
import { motion } from "framer-motion";
import { Skull, Menu, X } from "lucide-react";
import { useState } from "react";

export function Header() {
  const [location] = useLocation();
  const [isOpen, setIsOpen] = useState(false);

  const navItems = [
    { label: "Home", href: "/" },
    { label: "Tarot", href: "/tarot" },
    { label: "Ouija", href: "/ouija" },
    { label: "Fortune", href: "/fortune" },
    { label: "VooDoo", href: "/voodoo" },
  ];

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-black/80 backdrop-blur-md border-b border-white/5">
      <div className="max-w-7xl mx-auto px-4 h-20 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-3 group cursor-pointer">
          <motion.div 
            whileHover={{ rotate: 10, scale: 1.1 }}
            className="relative"
          >
            <img 
              src="https://i.ibb.co/Rkkfn8jY/Voo-Doo.png" 
              alt="VooDoo Logo" 
              className="h-12 w-auto drop-shadow-[0_0_10px_rgba(139,0,0,0.5)]"
            />
          </motion.div>
          <span className="font-creepster text-3xl text-primary tracking-wider group-hover:text-red-500 transition-colors">
            VooDoo
          </span>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-8">
          {navItems.map((item) => (
            <Link key={item.href} href={item.href} className={`
              font-cinzel text-sm font-bold tracking-widest uppercase transition-all duration-300
              ${location === item.href 
                ? "text-secondary text-glow scale-110" 
                : "text-muted-foreground hover:text-white hover:text-glow"}
            `}>
              {item.label}
            </Link>
          ))}
        </nav>

        {/* Mobile Toggle */}
        <button 
          className="md:hidden text-white p-2"
          onClick={() => setIsOpen(!isOpen)}
        >
          {isOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Mobile Nav */}
      {isOpen && (
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="md:hidden absolute top-20 left-0 right-0 bg-black border-b border-white/10 p-4 flex flex-col gap-4"
        >
          {navItems.map((item) => (
            <Link 
              key={item.href} 
              href={item.href} 
              className="font-cinzel text-lg text-center py-2 text-white hover:text-secondary"
              onClick={() => setIsOpen(false)}
            >
              {item.label}
            </Link>
          ))}
        </motion.div>
      )}
    </header>
  );
}

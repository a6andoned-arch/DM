## Packages
framer-motion | Essential for flashy animations, page transitions, and game effects
clsx | For conditional class merging
tailwind-merge | For safe tailwind class merging
html2canvas | For taking screenshots of the VooDoo doll (requested feature)

## Notes
Using 'Creepster' and 'Cinzel' from Google Fonts for the VooDoo aesthetic.
Tarot and Fortune API endpoints are defined in shared/routes.
VooDoo doll and Ouija board will be implemented as interactive frontend components.
Theme is strictly dark mode.
